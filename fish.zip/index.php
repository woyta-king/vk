<?php
header('Location: vk.php')
?>